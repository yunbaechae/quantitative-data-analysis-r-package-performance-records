# Welcome!

Please inspect this [Github Pages](https://david-yunbae.github.io/assignment2-question2-david-yunbae/)!

**I have noticed that I can't activate the private repo for a "Pages". The link above is not a subsidiary of this MQ-STAT1378 private repo. It is of an external public repo (My own). As specified in the prompts, I have artificially added those website related files in this repo. Please inspect those two files:**

- _config.yml
- index.md

**Note: the Github Pages is not deployed from that index.md in this repo. It is deployed from my own public repo. I would like to provide the repository upon request!**
