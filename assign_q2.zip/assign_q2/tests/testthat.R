library(testthat)
library(Ex2)

test_check("Ex2")
